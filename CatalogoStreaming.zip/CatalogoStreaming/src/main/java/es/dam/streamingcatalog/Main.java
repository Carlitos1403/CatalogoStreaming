package es.dam.streamingcatalog;

import es.dam.streamingcatalog.model.Critica;
import es.dam.streamingcatalog.model.Estudio;
import es.dam.streamingcatalog.model.Pelicula;
import es.dam.streamingcatalog.repository.EstudioRepository;
import es.dam.streamingcatalog.repository.PeliculaRepository;

import java.time.LocalDate;
import java.util.List;

public class Main {
    private static final EstudioRepository estudioRepository = new EstudioRepository();
    private static final PeliculaRepository peliculaRepository = new PeliculaRepository();

    public static void main(String[] args) {

        System.out.println("Estudio, Películas y Críticas creandose");

        Estudio estudio = new Estudio("Marvel", LocalDate.of(2025, 2, 12));

        Pelicula thor = new Pelicula("thor", 2010, "Accion", null);
        Pelicula spiderman = new Pelicula("Spiderman", 2012, "Ciencia Ficcion", null);

        estudio.addPelicula(thor);
        estudio.addPelicula(spiderman);

        thor.addCritica(new Critica("Anonimo1234", 9, "Los efectos son increibles", null));
        spiderman.addCritica(new Critica("Anonimo5678", 10, "La volveria a ver 100 veces", null));

        estudio = estudioRepository.guardar(estudio);
        System.out.println("Estudio, Peliculas y Críticas guardados correctamente");
        System.out.println("Id de Estudio creado correctamente " + estudio.getId());

        Pelicula peliculaToUpdate = estudio.getPeliculas().stream()
                .filter(p -> p.getTitulo().equals("thor"))
                .findFirst().orElseThrow(); //moodle

        System.out.println("En la Pelicula de 'thor' su ID es: " + peliculaToUpdate.getId());


        System.out.println("\n Actualizando el año de la Pelicula");
        peliculaToUpdate.setAnioLanzamiento(2006); 

        peliculaRepository.guardar(peliculaToUpdate);

        int anioActualizado = peliculaRepository.buscarporID(peliculaToUpdate.getId()).get().getAnioLanzamiento();
        System.out.println("Año de la pelicula '" + peliculaToUpdate.getTitulo() + "' actualizado a " + anioActualizado);

        int anioBusqueda = 2009;
        System.out.println("\n Buscando las películas despues del año " + anioBusqueda);
        List<Pelicula> peliculasRecientes = peliculaRepository.encontrarAnioMayorQue(anioBusqueda);
        peliculasRecientes
                .forEach(p -> System.out.println("Titulo= " + p.getTitulo() + "|| Año= " + p.getAnioLanzamiento()));
    }
}

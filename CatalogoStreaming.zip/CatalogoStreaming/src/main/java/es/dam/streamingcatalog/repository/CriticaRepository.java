package es.dam.streamingcatalog.repository;

import es.dam.streamingcatalog.model.Critica;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

import java.util.List;
import java.util.Optional;

public class CriticaRepository {

    private final EntityManagerFactory enmafa = Persistence.createEntityManagerFactory("streaming-catalog-pu");

    public Critica guardar(Critica entidad) {

        EntityManager enma = enmafa.createEntityManager();
        EntityTransaction entrans = null;

        try {
            entrans = enma.getTransaction();
            entrans.begin();

            Critica managed;
            if (entidad.getId() == null) {
                enma.persist(entidad);
                managed = entidad;

            } else {
                managed = enma.merge(entidad);
            }

            entrans.commit();
            return managed;

        } catch (Exception e) {

            if (entrans != null && entrans.isActive()) entrans.rollback();
            System.err.println("Error al guardar la Critica: " + e.getMessage());
            throw e;

        } finally {
            enma.close();
        }
    }

    public Optional<Critica> buscarporId(Long id) {

        EntityManager enma = enmafa.createEntityManager();
        try {

            return Optional.ofNullable(enma.find(Critica.class, id));
        } finally {

            enma.close();
        }
    }

    public List<Critica> buscarTodo() {
        EntityManager enma = enmafa.createEntityManager();
        try {
            String jpql = "SELECT c FROM Critica c";
            return enma.createQuery(jpql, Critica.class).getResultList();
        } finally {
            enma.close();
        }
    }

    public void borrar(Critica entity) {
        EntityManager enma = enmafa.createEntityManager();
        EntityTransaction entrans = null;

        try {
            entrans = enma.getTransaction();
            entrans.begin();

            Critica managed = enma.contains(entity) ? entity : enma.merge(entity);
            enma.remove(managed);

            entrans.commit();
        } catch (Exception e) {

            if (entrans != null && entrans.isActive()) entrans.rollback();
            System.err.println("Error al eliminar la Critica: " + e.getMessage());
            throw e;

        } finally {
            enma.close();
        }
    }

    public void borrarporId(Long id) {
        buscarporId(id).ifPresent(this::borrar);
    }
}

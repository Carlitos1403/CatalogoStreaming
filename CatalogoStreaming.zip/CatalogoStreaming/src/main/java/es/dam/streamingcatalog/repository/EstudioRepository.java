package es.dam.streamingcatalog.repository;

import es.dam.streamingcatalog.model.Estudio;
import jakarta.persistence.Persistence;
import java.util.List;
import java.util.Optional;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;


public class EstudioRepository {

    private final EntityManagerFactory enmafa = Persistence.createEntityManagerFactory("streaming-catalog-pu");

    public Estudio guardar(Estudio entidad) {

        EntityManager enma = enmafa.createEntityManager();
        EntityTransaction entra = null;
        try {

            entra = enma.getTransaction();
            entra.begin();

            Estudio managed;
            if (entidad.getId() == null) {
                enma.persist(entidad);
                managed = entidad;
            } else {
                managed = enma.merge(entidad);
            }

            entra.commit();
            return managed;
        } catch (Exception e) {

            if (entra != null && entra.isActive()) entra.rollback();
            System.err.println(" Error al guardar el Estudio: " + e.getMessage());
            throw e;

        } finally {
            enma.close();
        }
    }

    public Optional<Estudio> encontrarporID(Long id) {
        EntityManager enma = enmafa.createEntityManager();

        try {

            return Optional.ofNullable(enma.find(Estudio.class, id));

        } finally {
            enma.close();
        }
    }

    public List<Estudio> encontrarTodos() {

        EntityManager enma = enmafa.createEntityManager();
        try {

            String jpql = "SELECT e FROM Estudio e";
            return enma.createQuery(jpql, Estudio.class).getResultList();

        } finally {
            enma.close();
        }
    }

    public void borrar(Estudio entidad) {
        EntityManager enma = enmafa.createEntityManager();

        EntityTransaction entra = null;
        try {
            entra = enma.getTransaction();
            entra.begin();

            Estudio managed = enma.contains(entidad) ? entidad : enma.merge(entidad);
            enma.remove(managed);

            entra.commit();
        } catch (Exception e) {

            if (entra != null && entra.isActive()) entra.rollback();
            System.err.println("Error al eliminar Estudio: " + e.getMessage());
            throw e;

        } finally {
            enma.close();
        }
    }

    public void borrarporID(Long id) {
        encontrarporID(id).ifPresent(this::borrar);
    }
}

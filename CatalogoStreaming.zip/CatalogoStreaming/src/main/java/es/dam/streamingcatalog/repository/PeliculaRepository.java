package es.dam.streamingcatalog.repository;

import es.dam.streamingcatalog.model.Pelicula;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

import java.util.List;
import java.util.Optional;

public class PeliculaRepository {

    private final EntityManagerFactory enmafa = Persistence.createEntityManagerFactory("streaming-catalog-pu");


    public Optional<Pelicula> buscarporID(Long id) {

        EntityManager enma = enmafa.createEntityManager();
        try {
            
            return Optional.ofNullable(enma.find(Pelicula.class, id));
        } finally {
            enma.close();
        }
    }

    public List<Pelicula> encontrarTodo() {
        EntityManager enma = enmafa.createEntityManager();

        try {

            String jpql = "SELECT p FROM Pelicula p";
            return enma.createQuery(jpql, Pelicula.class).getResultList();

        } finally {
            enma.close();
        }
    }

    public List<Pelicula> encontrarAnioMayorQue(int anio) {

        EntityManager enma = enmafa.createEntityManager();
        try {

            String jpql = "SELECT p FROM Pelicula p WHERE p.anioLanzamiento > :anio";
            return enma.createQuery(jpql, Pelicula.class)
                     .setParameter("anio", anio)
                     .getResultList();

        } finally {
            enma.close();
        }
    }

    public Pelicula guardar(Pelicula entity) {

        EntityManager enma = enmafa.createEntityManager();
        EntityTransaction entrans = null;

        try {
            entrans = enma.getTransaction();
            entrans.begin();

            Pelicula managed;
            if (entity.getId() == null) {

                enma.persist(entity);
                managed = entity;
            } else {
                managed = enma.merge(entity);
            }

            entrans.commit();
            return managed;
        } catch (Exception e) {

            if (entrans != null && entrans.isActive()) entrans.rollback();
            System.err.println(" Error al guardar Pelicula: " + e.getMessage());
            throw e;

        } finally {
            enma.close();
        }
    }    
}
